package com.alons.marvel_universe.data.data_source.dto.CharactersDTO

data class ItemXX(
    val name: String,
    val resourceURI: String
)
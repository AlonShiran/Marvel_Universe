package com.alons.marvel_universe.data.data_source.dto.CharactersDTO

data class Item(
    val name: String,
    val resourceURI: String
)
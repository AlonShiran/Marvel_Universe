package com.alons.marvel_universe.data.data_source.dto.CharacterDTO

data class ItemXX(
    val name: String,
    val resourceURI: String
)
package com.alons.marvel_universe.data.data_source.dto.CharactersDTO

data class Thumbnail(
    val extension: String,
    val path: String
)
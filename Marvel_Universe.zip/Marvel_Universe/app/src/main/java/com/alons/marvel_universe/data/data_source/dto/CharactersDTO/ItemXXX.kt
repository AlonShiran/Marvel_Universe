package com.alons.marvel_universe.data.data_source.dto.CharactersDTO

data class ItemXXX(
    val name: String,
    val resourceURI: String,
    val type: String
)
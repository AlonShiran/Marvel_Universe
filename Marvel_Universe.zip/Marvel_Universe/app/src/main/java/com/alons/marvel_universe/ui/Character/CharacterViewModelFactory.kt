package com.alons.marvel_universe.ui.Character




    import androidx.lifecycle.ViewModel
    import androidx.lifecycle.ViewModelProvider
    import com.alons.marvel_universe.domain.use_cases.CharacterUseCase

class CharacterViewModelFactory( private val characterUseCase: CharacterUseCase) : ViewModelProvider.Factory {

        override fun <T : ViewModel> create(modelClass: Class<T>): T {
            return CharacterViewModelFactory(characterUseCase) as T

        }
    }
